(function(){
"use strict";
angular.module('iceCream')
.controller('desktopCtrl',['$rootScope','$state','$scope'
    ,function($rootScope,$state,$scope){
         console.log("......desktop........");
}]);
})();