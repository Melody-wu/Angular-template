//created by wml
    'use strict';
    angular.module('iceCream')
    .run(['$rootScope','$location','$state','storage'
        ,function($rootScope,$location,$state,storage){
            $rootScope.$on('$stateChangeSuccess',function(event, toState, toParams, fromState, fromParams){
            });
    }])
    .constant('ICE',{
        'wml':"wml&af",
        "ice_cookie":"ICE_ID",
        "ice_token":"UID_TOKEN"
    })
    .constant('ENV', {
        baseUrl: ''
    });