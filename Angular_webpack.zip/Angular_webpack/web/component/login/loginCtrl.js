(function(){
"use strict";
angular.module('iceCream')
.controller('mainCtrl',['$scope','$http',function($scope,$http){
     console.log("......main.......")
}])
.controller('loginCtrl',['$rootScope','$state','$scope'
    ,function($rootScope,$state,$scope){
         console.log("......login........");
}]);
})();