'use strict';
var ice=angular.module('iceCream',['ui.router','ngAnimate','ngResource','angularFileUpload']);
ice.config(['$stateProvider','$urlRouterProvider',function($stateProvider,$urlRouterProvider){
    $urlRouterProvider.otherwise('/login');
    $stateProvider
        .state('login',{
            url:'/login',
            views:{
                '':{
                    templateUrl:'component/login/login.html',
                    controller:'loginCtrl'
                }
            }
        })
        .state('stage',{
            url:'/stage',
            views:{
                '':{
                    templateUrl:'component/stage/stage.html',
                    controller:'stageCtrl'
                }
            }
        })
        .state('backstage',{
            url:'/backstage',
            views:{
                '':{
                    templateUrl:'component/backstage/backstage.html',
                    controller:'backStageCtrl'
                },
                'viewContent@backstage':{
                    templateUrl:'component/desktop/desktop.html',
                    controller:'desktopCtrl'
                }
            }
        })
        .state('backstage.desktop',{
            url:'/desktop',
             views:{
                'viewContent':{
                    templateUrl:'component/desktop/desktop.html',
                    controller:'desktopCtrl'
                }
            }
        });
}])
        .config(['$httpProvider', function ($httpProvider) {
            /*
            * post请求需要兼容两种请求数据格式,json和form
            * 兼容方案:以前通用使用form格式,现在需要兼容json格式
            * */

            $httpProvider.defaults.headers.put['Content-Type']
                = 'application/x-www-form-urlencoded';

            $httpProvider.defaults.headers.post['Content-Type']
                = 'application/x-www-form-urlencoded';
            // $httpProvider.interceptors.push('myInterceptors');
            $httpProvider.defaults.transformRequest
                = [function (data) {
                //debugger;
                if(data && data['jsonForm']){
                    //delete data.jsonForm;
                    return JSON.stringify(data);
                }

                /**

                 *
                 The workhorse; converts an object to x-www-form-urlencoded serialization.

                 *
                 @param {Object} obj

                 *
                 @return {String}

                 */

                var

                    param = function (obj) {
                        var

                            query = '';

                        var
                            name, value, fullSubName, subName, subValue, innerObj, i;


                        for
                            (name in obj) {

                            value
                                = obj[name];


                            if
                            (value instanceof Array) {

                                for
                                (i = 0; i < value.length; ++i) {

                                    subValue
                                        = value[i];

                                    fullSubName
                                        = name + '['
                                        + i + ']';

                                    innerObj
                                        = {};

                                    innerObj[fullSubName]
                                        = subValue;

                                    query
                                        += param(innerObj) + '&';

                                }

                            }
                            else if (value instanceof Object) {

                                for
                                    (subName in value) {

                                    subValue
                                        = value[subName];

                                    fullSubName
                                        = name + '['
                                        + subName + ']';

                                    innerObj
                                        = {};

                                    innerObj[fullSubName]
                                        = subValue;

                                    query
                                        += param(innerObj) + '&';

                                }

                            }
                            else if (value !== undefined && value !== null) {
                                query += encodeURIComponent(name) + '=' + encodeURIComponent(value) + '&';
                            }
                        }
                        return query.length ? query.substr(0, query.length - 1) : query;

                    };


                return angular.isObject(data) && String(data) !== '[object File]' ? param(data) : data;

            }];
        }]
    );