/**
**created by wml
**	dist files
**/
	require("../web/config/appRouter.js");
	/**指令    部分**/
	/**业务逻辑 部分**/
	// require('../web/service/*.js');

	/*******filter****/
	// require("../web/filter/*.js");

	/**控制器**/
	require("../web/component/login/loginCtrl.js");
	require("../web/component/stage/stageCtrl.js");
	require("../web/component/backstage/backstageCtrl.js");
	require("../web/component/desktop/desktopCtrl.js");
	//css 部分
	import '../web/style/ice.css';
	import '../web/component/login/login.css';

