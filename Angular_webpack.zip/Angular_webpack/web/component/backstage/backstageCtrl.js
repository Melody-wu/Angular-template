(function(){
"use strict";
angular.module('iceCream')
.controller('backStageCtrl',['$rootScope','$state','$scope'
    ,function($rootScope,$state,$scope){
         console.log("......backstage........");
}]);
})();