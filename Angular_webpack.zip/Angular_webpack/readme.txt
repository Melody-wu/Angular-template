Created By wml
这个模版是基于webpack的。Angular 模版已经设置好了路由，如果你使用的是angular@1.6.x，你应该使用angular-ui-router.js@0.4.x,于此同时其余插件也应该update以下,如果项目出现错误，大都数是引文Version 不匹配造成的。


First 你应该bower install 安装前端所需的文件,把bower_components放在web下面。
Second 你应该npm install。同理。


* 你如果发现你的url 上面有一个！号。那是因为你用了0.4.x ui-router 造成的。在谷歌浏览器中为了搜索引擎的抓取，而特别区分的，你觉得不好看，可以使用0.2.x. 


-_- !以上纯属个人实践发现，如果不对的地方，请多多包涵。
