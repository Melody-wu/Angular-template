(function(){
"use strict";
angular.module('iceCream')
.controller('stageCtrl',['$rootScope','$state','$scope'
    ,function($rootScope,$state,$scope){
         /**********获取可是窗口***************/
         console.log("......stage........");
}]);
})();