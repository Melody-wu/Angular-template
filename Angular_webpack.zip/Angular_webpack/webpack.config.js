/**
**  creted by wml
**  2018/2/1
*/
var webpack = require('webpack');
var path = require('path');
var HtmlWebpackPlugin = require('html-webpack-plugin');
var ExtractTextPlugin = require('extract-text-webpack-plugin');
var OpenBrowserPlugin = require('open-browser-webpack-plugin');
var CopyWebpackPlugin = require('copy-webpack-plugin');

	const config={
		entry: {
			index:path.resolve(__dirname, './conf/file.js')
			//index:path.resolve(__dirname,'./entry.js')
		},
		    	output: {
	        path: path.resolve(__dirname, './dist/webapp/'),
	        filename: '[name].[hash].min.js'
    	},
    	module: {
	      		rules: [  //webpack 2
	      			{
		                test: /\.js|jsx$/,
		                exclude: path.resolve(__dirname, './node_modules'),
		                use: ['babel-loader']
		                // query: {
                  //   		presets: ['latest'] //按照最新的ES6语法规则去转换
                		// }
		            },
		            {
	                	test:/\.scss$/,
	                	exclude: path.resolve(__dirname, './node_modules'),
		                use: ExtractTextPlugin.extract({
					          fallback: "style-loader",
					          //use:['css-loader','sass-loader']
					          use:['css-loader?importLoaders=1',
					          {
					          	  loader:'postcss-loader',
				                    options:{
				                        plugins:function(){
				                            return [
				                                require('autoprefixer')({broswers:['last 5 versions']})
				                            ];
				                        }
				                    }
					          },
					          'sass-loader'
					          ]
        				})
		            },
		            {
	                	test:/\.css$/,
	                	exclude: path.resolve(__dirname, './node_modules'),
		                use: ExtractTextPlugin.extract({
					          fallback: "style-loader",
					          use:['css-loader?importLoaders=1',
					          {
					          	  loader:'postcss-loader',
				                    options:{
				                        plugins:function(){
				                            return [
				                                require('autoprefixer')({broswers:['last 5 versions']})
				                            ];
				                        }
				                    }
					          }
					          ]
        				})
		            },
		            {
		            	test:/\.(jpg|png|jpeg|gif)$/i,
		            	//use: 'url-loader?limit=1024'
		            	//use: 'file-loader?limit=1024&name=[path][name].[ext]&outputPath=img/&publicPath=output/'
		            	use:[
			            	{
			            		loader:'url-loader',
			            		options:{
			            			limit:1024,
			            			outputPath:'./images/'
			            		}
			            	}
		            	]
		            }
        ]
      	},
    	plugins:[
				new ExtractTextPlugin("[name]-[hash].css"),
				//抽离css代码
				//new ExtractTextPlugin("/css/style.css"),
					//要缩代码
				new webpack.optimize.UglifyJsPlugin({
			      	compress: {
			        warnings: false
			    	}
			    }),
    		        // html 模板插件
	        	new HtmlWebpackPlugin({
	            	//template: __dirname + '/app/index.tmpl.html'
	            	template: __dirname + '/web/index.tmpl.html'
	        	}),
	        	    // 热加载插件
	        	new webpack.HotModuleReplacementPlugin(),

		        	// 打开浏览器
		        // new OpenBrowserPlugin({
		        //   		//url: 'http://localhost:8080'
		        //   		url:'192.168.2.255:8080'
		        // }),
		        //如果路径设置为webapp下,那整个工程的目录又会多了一层需要改变上面output输出的路径
		        new CopyWebpackPlugin([{
    				from: __dirname + '/web/',
    				to : __dirname + '/dist/webapp/'

				}])
				//{
				// 	ignore:__dirname + '/web/images'
				// })
	    ],
	    devServer: {
			proxy: {
		          // 凡是 `/ice_dev` 开头的 http 请求，都会被代理到 localhost:8081 上(配置没问题后台有问题要清理刷新或者重新加载报错504，如果报404得记录原因)
		          '/ice_dev': {
		           target: 'http://localhost:8081/xx',
		           //target:'192.168.2.255:8081/xx',
		            secure: false,
		            changeOrigin: true
		          }
			 },
			//contentBase: "./app",
	        //contentBase: "./web", //本地服务器所加载的页面所在的目录
	       	//colors: true, //删除了
	       	// stats:{
	       	// 	colors:true
	       	// },
	       	 host:'localhost',
	       //	host:'192.168.2.106',
	       	port:8080,
	       	hot:true,
	       	open:true,
	        historyApiFallback: true, //不跳转
	        inline: true //实时刷新
			}
	    }
module.exports = config;